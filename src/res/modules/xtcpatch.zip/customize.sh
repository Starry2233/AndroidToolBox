SKIPUNZIP=0
PERSIST_FLAG="persist.skyimoo.xtcpatch"
PERSIST_VERSION="persist.xtcpatch.version"

display_disclaimer() {
    ui_print "*********************"
    ui_print "- 开始安装"
    ui_print "免责声明:"
    cat $MODPATH/eula.txt
    ui_print "- 如果您不同意《免责声明》，请在10秒内退出安装并还原手表状态"
    ui_print "- 10秒后将默认同意《免责声明》并继续安装"
    sleep 10
    ui_print "*********************"
}

check_first_install() {
    local accepted=$(getprop $PERSIST_FLAG)
    [ "$accepted" != "1" ] && {
        display_disclaimer
        setprop $PERSIST_FLAG 1
        resetprop -n $PERSIST_FLAG 1 2>/dev/null
    }
}

check_install_non_market_apps() {
    ui_print "- 检查未知来源安装权限"
    local value=$(settings get secure install_non_market_apps)
    
    if [ "$value" != "1" ]; then
        ui_print "- 正在开启未知来源安装权限"
        if settings put secure install_non_market_apps 1 ; then
            ui_print "- 权限开启成功"
        else
            ui_print "! 权限开启失败"
        fi
    else
        ui_print "- 权限已开启"
    fi
}

check_system_prop() {
    MODEL=$(getprop ro.product.innermodel) 
    case $MODEL in 
        I20|I25|I25C|I25D|I32|ND01|ND07|ND03)
            TARGET_FILE="system_$MODEL.prop"
            ;;
        *)
            TARGET_FILE="system_normal.prop"
            ;;
    esac
    ui_print "- 您的手表innermodel是：$MODEL"
    mv $MODPATH/prop_files/$TARGET_FILE $MODPATH/system.prop
    rm -R $MODPATH/prop_files
}

xtcpatch_set_permissions() {
    ui_print "- 设置权限"
    chmod 755 "$MODPATH/system/bin/curl"
    chown root:shell "$MODPATH/system/bin/curl"
    chmod 755 "$MODPATH/system/bin/xtcpartitionverify"
    chown root:shell "$MODPATH/system/bin/xtcpartitionverify"
}

set_version() {
    local version_code=$(grep 'versionCode=' "$MODPATH/module.prop" | cut -d'=' -f2)
    ui_print "- 设置XTCPatch版本号: $version_code"
    setprop $PERSIST_VERSION "$version_code"
    resetprop -n $PERSIST_VERSION "$version_code" 2>/dev/null
    setprop persist.sys.stresstest true
    resetprop persist.sys.adb.install 1
}

get_user_name() {
    local query_result=$(content query --uri content://com.xtc.provider/BaseDataProvider/watchId/1 --projection name 2>/dev/null)

    if [ $? -ne 0 ] || [ -z "$query_result" ] || [[ "$query_result" == *"null"* ]]; then
        return 1
    fi
    
    local user_name="${query_result#*name=}"
    user_name="${user_name%%[[:space:]]*}"
    user_name="${user_name%%,*}"
   
    if [ -n "$user_name" ]; then
        echo "$user_name"
    else
        return 1
    fi
}

hello_user() {
    local user_name
    if user_name=$(get_user_name); then
        ui_print "你好，$user_name"
    else
        ui_print "你好"
    fi
}

locate_systemplus_apk() {
    [ "$(getprop ro.build.version.sdk)" -eq 27 ] || return 1
    local apk_path=$(pm path com.huanli233.systemplus 2>/dev/null | sed 's/package://g' | tr -d '\r\n')
    ui_print "- 找到SystemPlus APK: $apk_path"

    if cp -f "$apk_path" "$MODPATH/system/app/SystemPlus/SystemPlus.apk"; then
        ui_print "- 已复制SystemPlus.apk"
        return 0
    else
        ui_print "! 复制APK失败"
        return 1
    fi
}

sdk27_active_module() {
    pm install -r -t -d $MODPATH/system/app/XTCPatch/XTCPatch.apk
    ui_print "- 激活SystemPlus、核心破解、XTCPatch_Xposed"
    sh "$MODPATH/active_module.sh" com.huanli233.systemplus
    sh "$MODPATH/active_module.sh" com.zcg.xtcpatch
    sh "$MODPATH/active_module.sh" com.coderstory.toolkit
}

main_installation() {
    hello_user
    check_first_install
    check_install_non_market_apps
    check_system_prop
    if [ "$(getprop ro.build.version.sdk)" -eq 27 ]; then
       sdk27_active_module
    fi
    xtcpatch_set_permissions
    set_version
    ui_print "- 安装完成"
}

main_installation